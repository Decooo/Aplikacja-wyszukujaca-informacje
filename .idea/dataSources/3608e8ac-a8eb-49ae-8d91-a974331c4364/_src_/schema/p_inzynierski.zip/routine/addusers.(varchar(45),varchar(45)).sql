CREATE PROCEDURE addusers(IN in_login VARCHAR(45), IN in_haslo VARCHAR(45))
  BEGIN
 insert into uzytkownik(login,haslo) values(in_login,in_haslo);
 END;
