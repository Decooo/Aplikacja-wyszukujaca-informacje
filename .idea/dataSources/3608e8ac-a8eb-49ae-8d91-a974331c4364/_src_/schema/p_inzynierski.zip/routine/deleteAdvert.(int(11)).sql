CREATE PROCEDURE deleteAdvert(IN idAdvert INT)
  BEGIN
delete from ogloszenie where id_ogloszenie=idAdvert;

END;
