CREATE PROCEDURE addAdverts(IN idUser INT, IN idKategoria INT, IN formaZatrudnienia INT, IN stanowisko INT,
                            IN tytul  VARCHAR(150), IN lokalizacja VARCHAR(100), IN zarobki INT, IN opis VARCHAR(5000))
  BEGIN
 insert into ogloszenie(id_uzytkownik,id_kategoria,id_forma_zatrudnienia,id_stanowisko,tytul,lokalizacja,zarobki,opis) values(idUser,idKategoria,formaZatrudnienia,stanowisko,tytul,lokalizacja,zarobki,opis);
END;
