CREATE PROCEDURE numbersRecords(OUT quantity INT)
  BEGIN
select count(id_ogloszenie) into quantity from ogloszenie;
END;
