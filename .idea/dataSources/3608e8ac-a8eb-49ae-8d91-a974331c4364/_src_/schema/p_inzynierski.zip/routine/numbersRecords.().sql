CREATE PROCEDURE numbersRecords(OUT quantity INT)
  BEGIN
select count(*) from ogloszenie;
END;
