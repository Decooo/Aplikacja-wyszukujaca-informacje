CREATE PROCEDURE updateAdverts(IN idKategoria INT, IN formaZatrudnienia INT, IN stanowisko INT, IN tytul VARCHAR(150),
                               IN lokalizacja VARCHAR(100), IN zarobki INT, IN opis VARCHAR(5000), IN idOgloszenie INT)
  BEGIN
UPDATE ogloszenie
SET
id_kategoria = idKategoria,
id_forma_zatrudnienia = formaZatrudnienia,
id_stanowisko = stanowisko,
tytul = tytul,
lokalizacja = lokalizacja,
zarobki = zarobki,
opis=opis
WHERE
id_ogloszenie=idOgloszenie;
END;
